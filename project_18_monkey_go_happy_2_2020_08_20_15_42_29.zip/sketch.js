var bananaImage,obstacleImage,obstaclegroup,backgroundImage,score,monkeyImage,ground,foodGroup;

function preload(){
bananaImage=loadImage("banana.png");
obstacleImage=loadImage("stone.png");
backgroundImage=loadImage("jungle.png");
monkeyImage=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png",)
}



function setup() {
  createCanvas(800, 400);

  
  
  ground=createSprite(0,370,400,5);
  jungle=createSprite(200,200,800,800);
  jungle.addImage("jungle",backgroundImage)
  jungle.x = jungle.width /2;
  jungle.velocityX = -4;
  
  jungle.scale=3.5  ;
  ground.visible=false;

  monkey=createSprite(15,365,10,10)
monkey.addAnimation("monkey",monkeyImage);

  foodGroup=new Group();
obstaclegroup=new Group();

score=0;  
}

function draw() {

  if(keyDown("space")&& monkey.y >= 160) {
    monkey.velocityY = -19;
  }
  
  monkey.velocityY = monkey.velocityY + 0.8
   
  switch (score){
      
    case 10: monkey.scale=monkey.scale+0.12
      break;
     case 20: monkey.scale=monkey.scale+0.14
      break;  
   case 30: monkey.scale=monkey.scale+0.16
      break;
  case 40: monkey.scale=monkey.scale+0.18
      break;
      default: break;
  }
  
  
  if(obstaclegroup.isTouching(monkey)){
    monkey.scale=0.25
  }
  
  if(foodGroup.isTouching(monkey)){
     banana.destroy();
     score=score+  2
   }
  
  if (jungle.x < 0){
    jungle.x = jungle.width/2;
  }
monkey.scale=0.25
  background("white");
  monkey.collide(ground);
  obstacle();
food();
  
     

  drawSprites();

  
  stroke("white");
  textSize(20);
  fill("white")
  text("score:" + score,490,30);

}



function food(){
if(frameCount%60===0){
  banana = createSprite(200,150,10,10)
banana.addImage("banana",bananaImage);
banana.y = Math.round(random(80,120));
  banana.x=720;
  banana.velocityX=-6;
  banana.lifetime=200
  banana.scale=0.10025
  banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
foodGroup.add(banana);
}
}


function obstacle(){
  if (frameCount%80===0){
    var obstacle=createSprite(200,310,10,10)
    
    obstacle.addImage("obstacle",obstacleImage);
    obstacle.x=720;
    obstacle.scale=0.25
    obstacle.velocityX=jungle.velocityX;
    obstacle.lifetime=300;
    
    obstaclegroup.add(obstacle);
  }
}